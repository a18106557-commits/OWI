class ReturnException(Exception):
    def __init__(self, valor):
        self.valor = valor

# ── Servidor web OWI ─────────────────────────────────────────────
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

class OWIServer:
    def __init__(self):
        self.rutas  = {}
        self.httpd  = None
        self.hilo   = None
        self.html_actual = None   # HTML que server.html() registra

    def registrar(self, ruta, fn):
        self.rutas[ruta] = fn

    def iniciar(self, puerto, interprete):
        rutas = self.rutas

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass

            def do_GET(self):
                if self.path in rutas:
                    interprete.servidor.html_actual = None
                    import io, sys
                    captura = io.StringIO()
                    sys_stdout = sys.stdout
                    sys.stdout = captura
                    try:
                        rutas[self.path]()
                        texto = captura.getvalue()
                    except Exception as e:
                        texto = f"Error OWI: {e}"
                    finally:
                        sys.stdout = sys_stdout

                    # si usaron server.html() usamos ese HTML
                    # si no, envolvemos el texto en HTML bonito
                    if interprete.servidor.html_actual is not None:
                        html = interprete.servidor.html_actual
                    elif texto.strip():
                        lineas = ''.join(f'<p>{l}</p>' for l in texto.strip().splitlines())
                        html = f"""<!DOCTYPE html>
<html><head><meta charset='utf-8'>
<style>body{{font-family:monospace;background:#0d0d0d;color:#00ff99;padding:2rem}}
p{{margin:0.3rem 0}}</style></head>
<body>{lineas}</body></html>"""
                    else:
                        html = "<html><body><p>OK</p></body></html>"

                    self.send_response(200)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self.end_headers()
                    self.wfile.write(html.encode())
                else:
                    self.send_response(404)
                    self.send_header('Content-type', 'text/html; charset=utf-8')
                    self.end_headers()
                    rutas_lista = ''.join(f'<li><a href="{r}">{r}</a></li>' for r in rutas)
                    html = f"""<!DOCTYPE html>
<html><head><meta charset='utf-8'>
<style>body{{font-family:monospace;background:#0d0d0d;color:#ff4444;padding:2rem}}
a{{color:#00ff99}}</style></head>
<body><h2>404 — {self.path} no encontrada</h2>
<ul>{rutas_lista}</ul></body></html>"""
                    self.wfile.write(html.encode())

        self.httpd = HTTPServer(('', puerto), Handler)
        self.hilo  = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.hilo.start()
        print(f"🌐 OWI server corriendo en http://localhost:{puerto}")

    def detener(self):
        if self.httpd:
            self.httpd.shutdown()
            print("🛑 OWI server detenido")

class Interprete:
    def __init__(self):
        self.entorno   = {}
        self.funciones = {}
        self.inmutables = set()
        self.servidor   = OWIServer()

    def ejecutar(self, nodos):
        for nodo in nodos:
            self.ejecutar_nodo(nodo)

    def ejecutar_nodo(self, nodo):
        if nodo is None:
            return None
        tipo = nodo[0]

        if tipo == 'DECLARAR_VARIABLE':
            _, tipo_var, nombre, valor_nodo = nodo
            valor = self.evaluar(valor_nodo)
            self.entorno[nombre] = valor
            return valor

        elif tipo == 'LET':
            _, mutable, tipo_var, nombre, valor_nodo = nodo
            valor = self.evaluar(valor_nodo)
            self.entorno[nombre] = valor
            if not mutable:
                self.inmutables.add(nombre)
            return valor

        elif tipo == 'ASIGNAR_VARIABLE':
            _, nombre, valor_nodo = nodo
            if nombre in self.inmutables:
                raise Exception(f"'{nombre}' es inmutable. Usa 'let mut' para poder cambiarla.")
            valor = self.evaluar(valor_nodo)
            self.entorno[nombre] = valor
            return valor

        elif tipo == 'DECLARAR_FUNCION':
            _, nombre, params, cuerpo = nodo
            self.funciones[nombre] = (params, cuerpo)

        elif tipo in ('LLAMAR_FUNCION', 'MODE'):
            return self.evaluar(nodo)

        elif tipo == 'CHECK':
            _, condicion, cuerpo_si, cuerpo_no = nodo
            if self.evaluar(condicion):
                self.ejecutar_bloque(cuerpo_si)
            else:
                self.ejecutar_bloque(cuerpo_no)

        elif tipo == 'MATCH':
            _, valor_nodo, casos = nodo
            valor = self.evaluar(valor_nodo)
            for patron, cuerpo in casos:
                if patron == ('DEFAULT',) or self.evaluar(patron) == valor:
                    self.ejecutar_bloque(cuerpo)
                    break

        elif tipo == 'WHILE':
            _, condicion, cuerpo = nodo
            while self.evaluar(condicion):
                self.ejecutar_bloque(cuerpo)

        elif tipo == 'FOR':
            _, var, inicio_nodo, fin_nodo, cuerpo = nodo
            inicio = int(self.evaluar(inicio_nodo))
            fin    = int(self.evaluar(fin_nodo))
            for i in range(inicio, fin + 1):
                self.entorno[var] = i
                self.ejecutar_bloque(cuerpo)

        elif tipo == 'TRY_CATCH':
            _, cuerpo_try, cuerpo_catch = nodo
            try:
                self.ejecutar_bloque(cuerpo_try)
            except Exception:
                self.ejecutar_bloque(cuerpo_catch)

        elif tipo == 'SERVER_CMD':
            _, accion, args = nodo
            if accion == 'start':
                puerto = int(self.evaluar(args[0])) if args else 8080
                self.servidor.iniciar(puerto, self)
                try:
                    import time
                    while True:
                        time.sleep(1)
                except KeyboardInterrupt:
                    self.servidor.detener()
            elif accion == 'stop':
                self.servidor.detener()
            elif accion == 'html':
                html = str(self.evaluar(args[0])) if args else ''
                self.servidor.html_actual = html

        elif tipo == 'SERVER_ROUTE':
            _, ruta_nodo, cuerpo = nodo
            ruta = self.evaluar(ruta_nodo)
            entorno_capturado = dict(self.entorno)
            interprete_ref    = self
            def handler(c=cuerpo, e=entorno_capturado):
                interprete_ref.entorno = dict(e)
                interprete_ref.ejecutar_bloque(c)
            self.servidor.registrar(ruta, handler)

        elif tipo == 'RETURN':
            raise ReturnException(self.evaluar(nodo[1]))

        return None

    def ejecutar_bloque(self, nodos, entorno_local=None):
        entorno_anterior  = self.entorno
        inmut_anterior    = self.inmutables.copy()
        if entorno_local is not None:
            self.entorno = entorno_local
        try:
            for nodo in nodos:
                self.ejecutar_nodo(nodo)
        finally:
            if entorno_local is not None:
                self.entorno    = entorno_anterior
                self.inmutables = inmut_anterior

    def evaluar(self, nodo):
        if nodo is None:
            return None
        tipo = nodo[0]

        if tipo == 'NUMBER': return nodo[1]
        if tipo == 'STRING': return nodo[1]
        if tipo == 'BOOL':   return nodo[1]
        if tipo == 'LIST':   return [self.evaluar(i) for i in nodo[1]]

        if tipo == 'ID':
            nombre = nodo[1]
            if nombre in self.entorno:
                return self.entorno[nombre]
            raise Exception(f"Variable '{nombre}' no definida")

        if tipo == 'BINOP':
            _, op, izq_n, der_n = nodo
            izq = self.evaluar(izq_n)
            der = self.evaluar(der_n)
            if op == '+':
                return str(izq)+str(der) if isinstance(izq,str) or isinstance(der,str) else izq+der
            if op == '-':  return izq - der
            if op == '*':  return izq * der
            if op == '/':  return izq / der
            if op == '==': return izq == der
            if op == '!=': return izq != der
            if op == '>=': return izq >= der
            if op == '<=': return izq <= der
            if op == '>':  return izq > der
            if op == '<':  return izq < der
            if op == 'and': return izq and der
            if op == 'or':  return izq or der

        if tipo == 'NOT':
            return not self.evaluar(nodo[1])

        if tipo == 'MODE':
            _, modo, args = nodo
            if modo == 'print':
                print(' '.join(str(self.evaluar(a)) for a in args))
                return None
            if modo == 'input':
                prompt = str(self.evaluar(args[0])) if args else ''
                return input(prompt)

        if tipo == 'LLAMAR_FUNCION':
            _, nombre, args_nodos = nodo
            if nombre not in self.funciones:
                raise Exception(f"Función '{nombre}' no definida")
            params, cuerpo = self.funciones[nombre]
            args_vals = [self.evaluar(a) for a in args_nodos]
            entorno_local = dict(self.entorno)
            for (p, _), v in zip(params, args_vals):
                entorno_local[p] = v
            entorno_anterior  = self.entorno
            inmut_anterior    = self.inmutables.copy()
            self.entorno    = entorno_local
            self.inmutables = set()
            resultado = None
            try:
                for n in cuerpo:
                    self.ejecutar_nodo(n)
            except ReturnException as r:
                resultado = r.valor
            finally:
                self.entorno    = entorno_anterior
                self.inmutables = inmut_anterior
            return resultado

        return None
