import sys
from lexer import lexer
from parser import Parser
from interprete import Interprete

def ejecutar_archivo(ruta):
    with open(ruta, 'r', encoding='utf-8') as f:
        codigo = f.read()
    tokens = lexer(codigo)
    parser = Parser(tokens)
    ast    = parser.parsear()
    interp = Interprete()
    interp.ejecutar(ast)

def repl():
    print("OWI REPL - escribe 'salir' para terminar")
    interp = Interprete()
    while True:
        try:
            linea = input("owi> ")
            if linea.strip() == 'salir':
                break
            tokens = lexer(linea)
            parser = Parser(tokens)
            ast    = parser.parsear()
            for nodo in ast:
                resultado = interp.ejecutar_nodo(nodo)
                if resultado is not None:
                    print("=>", resultado)
        except Exception as e:
            print(f"Error: {e}")

if __name__ == '__main__':
    if len(sys.argv) > 1:
        ejecutar_archivo(sys.argv[1])
    else:
        repl()
