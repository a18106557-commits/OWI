from lexer import lexer

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def actual(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def ver(self, offset=1):
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return None

    def consumir(self, tipo=None, valor=None):
        token = self.actual()
        if tipo and (not token or token[0] != tipo):
            raise Exception(f"Se esperaba {tipo} pero se encontró {token}")
        if valor and (not token or token[1] != valor):
            raise Exception(f"Se esperaba '{valor}' pero se encontró {token}")
        self.pos += 1
        return token

    def saltar_terminadores(self):
        while self.actual() and self.actual()[0] == 'END_STMT':
            self.pos += 1

    def parsear(self):
        nodos = []
        while self.actual() is not None:
            self.saltar_terminadores()
            if self.actual() is None:
                break
            nodo = self.statement()
            if nodo:
                nodos.append(nodo)
        return nodos

    def statement(self):
        token = self.actual()
        if not token:
            return None

        # let x = valor  /  let mut x = valor  /  let x: tipo = valor
        if token[0] == 'KEYWORD' and token[1] == 'let':
            return self.declarar_let()

        # text x = valor  /  num x = valor  /  bool x = valor  /  list x = [...]
        if token[0] == 'KEYWORD' and token[1] in ('text', 'num', 'bool', 'list'):
            return self.declarar_variable()

        # using_function
        elif token[0] == 'FUNC_DEF':
            return self.declarar_funcion()

        # using_nombre(args)
        elif token[0] == 'FUNC_CALL':
            return self.llamar_funcion()

        # mode.print / mode.input / etc
        elif token[0] == 'MODE':
            return self.mode_statement()

        # server.start / server.route / server.stop
        elif token[0] == 'SERVER':
            return self.server_statement()

        # check (cond) { } else { }
        elif token[0] == 'KEYWORD' and token[1] == 'check':
            return self.condicional()

        # match valor { with X => { } }
        elif token[0] == 'KEYWORD' and token[1] == 'match':
            return self.match_statement()

        # while (cond) { }
        elif token[0] == 'KEYWORD' and token[1] == 'while':
            return self.bucle_while()

        # for i = 0 to 10 { }
        elif token[0] == 'KEYWORD' and token[1] == 'for':
            return self.bucle_for()

        # try { } catch { }
        elif token[0] == 'KEYWORD' and token[1] == 'try':
            return self.manejo_error()

        # return valor
        elif token[0] == 'KEYWORD' and token[1] == 'return':
            return self.retorno()

        # nombre = valor  (reasignación)
        elif token[0] == 'ID' and self.ver() and self.ver()[0] == 'IGUAL':
            return self.asignar_variable()

        else:
            self.pos += 1
            return None

    # ── let / let mut ───────────────────────────────────────────
    def declarar_let(self):
        self.consumir('KEYWORD', 'let')
        mutable = False
        if self.actual() and self.actual() == ('KEYWORD', 'mut'):
            self.consumir('KEYWORD', 'mut')
            mutable = True
        nombre = self.consumir('ID')[1]
        # tipo opcional: let x: num = 5
        tipo_var = None
        if self.actual() and self.actual()[0] == 'COLON':
            self.consumir('COLON')
            # el tipo puede ser KEYWORD (text, num, bool) o ID
            t = self.actual()
            if t and t[0] in ('KEYWORD', 'ID'):
                tipo_var = t[1]
                self.pos += 1
        self.consumir('IGUAL')
        valor = self.expresion()
        return ('LET', mutable, tipo_var, nombre, valor)

    # ── Variables clásicas OWI ──────────────────────────────────
    def declarar_variable(self):
        tipo_var = self.consumir('KEYWORD')[1]
        nombre   = self.consumir('ID')[1]
        self.consumir('IGUAL')
        valor    = self.expresion()
        return ('DECLARAR_VARIABLE', tipo_var, nombre, valor)

    def asignar_variable(self):
        nombre = self.consumir('ID')[1]
        self.consumir('IGUAL')
        valor  = self.expresion()
        return ('ASIGNAR_VARIABLE', nombre, valor)

    # ── Funciones ───────────────────────────────────────────────
    def declarar_funcion(self):
        self.consumir('FUNC_DEF')
        nombre = self.consumir('ID')[1]
        self.consumir('LPAREN')
        params = self.lista_params()
        self.consumir('RPAREN')
        self.consumir('LBRACE')
        cuerpo = self.bloque()
        self.consumir('RBRACE')
        return ('DECLARAR_FUNCION', nombre, params, cuerpo)

    def llamar_funcion(self):
        token  = self.consumir('FUNC_CALL')
        nombre = token[1][len('using_'):]
        self.consumir('LPAREN')
        args   = self.lista_args()
        self.consumir('RPAREN')
        return ('LLAMAR_FUNCION', nombre, args)

    def lista_params(self):
        params = []
        while self.actual() and self.actual()[0] != 'RPAREN':
            nombre = self.consumir('ID')[1]
            tipo   = None
            if self.actual() and self.actual()[0] == 'COLON':
                self.consumir('COLON')
                tipo = self.consumir('ID')[1]
            params.append((nombre, tipo))
            if self.actual() and self.actual()[0] == 'COMMA':
                self.consumir('COMMA')
        return params

    def lista_args(self):
        args = []
        while self.actual() and self.actual()[0] != 'RPAREN':
            args.append(self.expresion())
            if self.actual() and self.actual()[0] == 'COMMA':
                self.consumir('COMMA')
        return args

    # ── server.X ────────────────────────────────────────────────
    def server_statement(self):
        token = self.consumir('SERVER')
        accion = token[1].split('.')[1]
        if accion == 'route':
            self.consumir('LPAREN')
            ruta = self.expresion()
            self.consumir('RPAREN')
            self.consumir('LBRACE')
            cuerpo = self.bloque()
            self.consumir('RBRACE')
            return ('SERVER_ROUTE', ruta, cuerpo)
        else:
            # server.start(8080) / server.stop() / server.html("...")
            self.consumir('LPAREN')
            args = self.lista_args()
            self.consumir('RPAREN')
            return ('SERVER_CMD', accion, args)

    # ── mode.X ──────────────────────────────────────────────────
    def mode_statement(self):
        token = self.consumir('MODE')
        modo  = token[1].split('.')[1]
        self.consumir('LPAREN')
        args  = self.lista_args()
        self.consumir('RPAREN')
        return ('MODE', modo, args)

    # ── check / else ────────────────────────────────────────────
    def condicional(self):
        self.consumir('KEYWORD', 'check')
        self.consumir('LPAREN')
        condicion = self.expresion()
        self.consumir('RPAREN')
        self.consumir('LBRACE')
        cuerpo_si = self.bloque()
        self.consumir('RBRACE')
        cuerpo_no = []
        if self.actual() and self.actual() == ('KEYWORD', 'else'):
            self.consumir('KEYWORD', 'else')
            self.consumir('LBRACE')
            cuerpo_no = self.bloque()
            self.consumir('RBRACE')
        return ('CHECK', condicion, cuerpo_si, cuerpo_no)

    # ── match ────────────────────────────────────────────────────
    # match valor {
    #   with 1 => { ... }
    #   with "hola" => { ... }
    #   with _ => { ... }   <- default
    # }
    def match_statement(self):
        self.consumir('KEYWORD', 'match')
        valor = self.expresion()
        self.consumir('LBRACE')
        casos = []
        self.saltar_terminadores()
        while self.actual() and self.actual()[0] != 'RBRACE':
            self.consumir('KEYWORD', 'with')
            # patron: valor literal o _ (default)
            if self.actual() and self.actual()[0] == 'ID' and self.actual()[1] == '_':
                self.pos += 1
                patron = ('DEFAULT',)
            else:
                patron = self.expresion()
            self.consumir('ARROW')
            self.consumir('LBRACE')
            cuerpo = self.bloque()
            self.consumir('RBRACE')
            casos.append((patron, cuerpo))
            self.saltar_terminadores()
        self.consumir('RBRACE')
        return ('MATCH', valor, casos)

    # ── while ────────────────────────────────────────────────────
    def bucle_while(self):
        self.consumir('KEYWORD', 'while')
        self.consumir('LPAREN')
        condicion = self.expresion()
        self.consumir('RPAREN')
        self.consumir('LBRACE')
        cuerpo = self.bloque()
        self.consumir('RBRACE')
        return ('WHILE', condicion, cuerpo)

    # ── for ──────────────────────────────────────────────────────
    def bucle_for(self):
        self.consumir('KEYWORD', 'for')
        var    = self.consumir('ID')[1]
        self.consumir('IGUAL')
        inicio = self.expresion()
        self.consumir('KEYWORD', 'to')
        fin    = self.expresion()
        self.consumir('LBRACE')
        cuerpo = self.bloque()
        self.consumir('RBRACE')
        return ('FOR', var, inicio, fin, cuerpo)

    # ── try / catch ──────────────────────────────────────────────
    def manejo_error(self):
        self.consumir('KEYWORD', 'try')
        self.consumir('LBRACE')
        cuerpo_try = self.bloque()
        self.consumir('RBRACE')
        self.consumir('KEYWORD', 'catch')
        self.consumir('LBRACE')
        cuerpo_catch = self.bloque()
        self.consumir('RBRACE')
        return ('TRY_CATCH', cuerpo_try, cuerpo_catch)

    # ── return ───────────────────────────────────────────────────
    def retorno(self):
        self.consumir('KEYWORD', 'return')
        valor = self.expresion()
        return ('RETURN', valor)

    # ── bloque ───────────────────────────────────────────────────
    def bloque(self):
        nodos = []
        while self.actual() and self.actual()[0] != 'RBRACE':
            self.saltar_terminadores()
            if not self.actual() or self.actual()[0] == 'RBRACE':
                break
            nodo = self.statement()
            if nodo:
                nodos.append(nodo)
        return nodos

    # ── expresiones ──────────────────────────────────────────────
    def expresion(self):
        return self.expr_logica()

    def expr_logica(self):
        izq = self.expr_comparacion()
        while self.actual() and self.actual() in (('KEYWORD','and'), ('KEYWORD','or')):
            op  = self.consumir('KEYWORD')[1]
            der = self.expr_comparacion()
            izq = ('BINOP', op, izq, der)
        return izq

    def expr_comparacion(self):
        izq = self.expr_aritmetica()
        while self.actual() and self.actual()[0] == 'OP' and self.actual()[1] in ('==','!=','>=','<=','>','<'):
            op  = self.consumir('OP')[1]
            der = self.expr_aritmetica()
            izq = ('BINOP', op, izq, der)
        return izq

    def expr_aritmetica(self):
        izq = self.termino()
        while self.actual() and self.actual()[0] == 'OP' and self.actual()[1] in ('+', '-'):
            op  = self.consumir('OP')[1]
            der = self.termino()
            izq = ('BINOP', op, izq, der)
        return izq

    def termino(self):
        izq = self.factor()
        while self.actual() and self.actual()[0] == 'OP' and self.actual()[1] in ('*', '/'):
            op  = self.consumir('OP')[1]
            der = self.factor()
            izq = ('BINOP', op, izq, der)
        return izq

    def factor(self):
        token = self.actual()
        if not token:
            raise Exception("Expresión incompleta")

        if token == ('KEYWORD', 'not'):
            self.consumir('KEYWORD', 'not')
            return ('NOT', self.factor())

        if token[0] == 'KEYWORD' and token[1] in ('true', 'false'):
            self.pos += 1
            return ('BOOL', token[1] == 'true')

        if token[0] == 'STRING':
            self.pos += 1
            return ('STRING', token[1][1:-1])

        if token[0] == 'NUMBER':
            self.pos += 1
            val = float(token[1]) if '.' in token[1] else int(token[1])
            return ('NUMBER', val)

        if token[0] == 'FUNC_CALL':
            return self.llamar_funcion()

        if token[0] == 'MODE':
            return self.mode_statement()

        # lista: [1, 2, 3]
        if token[0] == 'LBRACKET':
            return self.lista_literal()

        if token[0] == 'ID':
            self.pos += 1
            return ('ID', token[1])

        if token[0] == 'LPAREN':
            self.consumir('LPAREN')
            expr = self.expresion()
            self.consumir('RPAREN')
            return expr

        raise Exception(f"Token inesperado: {token}")

    # ── lista literal [1, 2, 3] ──────────────────────────────────
    def lista_literal(self):
        self.consumir('LBRACKET')
        items = []
        while self.actual() and self.actual()[0] != 'RBRACKET':
            items.append(self.expresion())
            if self.actual() and self.actual()[0] == 'COMMA':
                self.consumir('COMMA')
        self.consumir('RBRACKET')
        return ('LIST', items)
