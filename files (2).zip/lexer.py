import re

TOKENS = [
    ('KEYWORD',   r'\b(text|num|bool|list|let|mut|match|with|check|else|for|to|while|try|catch|return|import|do|end|and|or|not|true|false)\b'),
    ('CLASS',     r'using_class'),
    ('FUNC_DEF',  r'using_function'),
    ('FUNC_CALL', r'using_[a-zA-Z_][a-zA-Z0-9_]*'),
    ('MODE',      r'mode\.(print|input|read|write|request)'),
    ('SERVER',    r'server\.(start|route|stop|html)'),
    ('STRING',    r'"[^"]*"|\'[^\']*\''),
    ('NUMBER',    r'\d+(\.\d+)?'),
    ('ID',        r'[a-zA-Z_][a-zA-Z0-9_]*'),
    ('ARROW',     r'=>'),
    ('OP',        r'>=|<=|==|!=|[+\-*/<>]'),
    ('IGUAL',     r'='),
    ('COLON',     r':'),
    ('LPAREN',    r'\('),
    ('RPAREN',    r'\)'),
    ('LBRACE',    r'\{'),
    ('RBRACE',    r'\}'),
    ('LBRACKET',  r'\['),
    ('RBRACKET',  r'\]'),
    ('COMMA',     r','),
    ('END_STMT',  r'::'),
    ('SKIP',      r'[ \t\n]+'),
    ('COMMENT',   r'#[^\n]*'),
    ('UNKNOWN',   r'.'),
]

def lexer(codigo):
    tokens = []
    while codigo:
        matched = False
        for tipo, patron in TOKENS:
            match = re.match(patron, codigo)
            if match:
                valor = match.group(0)
                if tipo not in ('SKIP', 'COMMENT', 'UNKNOWN'):
                    tokens.append((tipo, valor))
                codigo = codigo[len(valor):]
                matched = True
                break
        if not matched:
            codigo = codigo[1:]
    return tokens
